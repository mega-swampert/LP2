﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string matricula = txtMatricula.Text;
            int prod;
            double salBase, grat;

            if (!int.TryParse(txtProd.Text, out prod) ||
                !double.TryParse(txtSalBase.Text, out salBase) ||
                !double.TryParse(txtGrat.Text, out grat))
            {
                MessageBox.Show("Verifique os campos: Produção, Salário e Gratificação devem ser números válidos.");
                return;
            }

            int B = (prod >= 100) ? 1 : 0;
            int C = (prod >= 120) ? 1 : 0;
            int D = (prod >= 150) ? 1 : 0;

            double salarioBruto = salBase + salBase * (0.05 * B + 0.1 * C + 0.1 * D) + grat;

            if (salarioBruto > 7000)
            {
                if (!(prod >= 150 && grat > 0))
                {
                    salarioBruto = 7000.00;
                }
            }
            txtSalBruto.Text = salarioBruto.ToString("C2");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtMatricula.Clear();
            txtProd.Clear();
            txtSalBase.Clear();
            txtGrat.Clear();
            txtSalBruto.Clear();
        }
    }
}
