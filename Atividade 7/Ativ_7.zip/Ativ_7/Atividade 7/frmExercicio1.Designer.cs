﻿namespace Atividade_7
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxt = new System.Windows.Forms.RichTextBox();
            this.lblTexto = new System.Windows.Forms.Label();
            this.btnEspaceWht = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnNumPar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxt
            // 
            this.rchtxt.Location = new System.Drawing.Point(147, 79);
            this.rchtxt.Margin = new System.Windows.Forms.Padding(4);
            this.rchtxt.Name = "rchtxt";
            this.rchtxt.Size = new System.Drawing.Size(728, 148);
            this.rchtxt.TabIndex = 0;
            this.rchtxt.Text = "";
            this.rchtxt.TextChanged += new System.EventHandler(this.rchTextBox_TextChanged);
            this.rchtxt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.rchTextBox_KeyPress);
            // 
            // lblTexto
            // 
            this.lblTexto.AutoSize = true;
            this.lblTexto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexto.Location = new System.Drawing.Point(325, 49);
            this.lblTexto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTexto.Name = "lblTexto";
            this.lblTexto.Size = new System.Drawing.Size(348, 24);
            this.lblTexto.TabIndex = 1;
            this.lblTexto.Text = "Digite uma frase com até 100 carácteres:";
            // 
            // btnEspaceWht
            // 
            this.btnEspaceWht.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspaceWht.Location = new System.Drawing.Point(147, 303);
            this.btnEspaceWht.Margin = new System.Windows.Forms.Padding(4);
            this.btnEspaceWht.Name = "btnEspaceWht";
            this.btnEspaceWht.Size = new System.Drawing.Size(192, 166);
            this.btnEspaceWht.TabIndex = 2;
            this.btnEspaceWht.Text = "Quantos espaços em branco existem na frase";
            this.btnEspaceWht.UseVisualStyleBackColor = true;
            this.btnEspaceWht.Click += new System.EventHandler(this.btnEspaceWht_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetraR.Location = new System.Drawing.Point(416, 303);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(4);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(192, 166);
            this.btnLetraR.TabIndex = 3;
            this.btnLetraR.Text = "Quantos \"R\" existem na frase";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnNumPar
            // 
            this.btnNumPar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumPar.Location = new System.Drawing.Point(684, 303);
            this.btnNumPar.Margin = new System.Windows.Forms.Padding(4);
            this.btnNumPar.Name = "btnNumPar";
            this.btnNumPar.Size = new System.Drawing.Size(192, 166);
            this.btnNumPar.TabIndex = 4;
            this.btnNumPar.Text = "Quantos pares de letra existem na frase";
            this.btnNumPar.UseVisualStyleBackColor = true;
            this.btnNumPar.Click += new System.EventHandler(this.btnNumPar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnNumPar);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspaceWht);
            this.Controls.Add(this.lblTexto);
            this.Controls.Add(this.rchtxt);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.Load += new System.EventHandler(this.frmExercicio1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxt;
        private System.Windows.Forms.Label lblTexto;
        private System.Windows.Forms.Button btnEspaceWht;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnNumPar;
    }
}