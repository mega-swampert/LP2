﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Exerc4 : Form
    {
        public Exerc4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] Nomes = new string[10];
            int[] CompNomes = new int[10];

            for (int i = 0; i < Nomes.GetLength(0); i++)
            {
                string auxiliar = Interaction.InputBox($"Digite o {i + 1}º nome", "Entrada de Dados");

                if (string.IsNullOrEmpty(auxiliar) || (string.IsNullOrWhiteSpace(auxiliar)))
                {
                    MessageBox.Show("Nome Inválido!");
                    i--;
                }
                else
                {
                    Nomes[i] = auxiliar;
                }


                CompNomes[i] = Nomes[i].Replace(" ", "").Length;

                lstbxNomes.Items.Add($"O nome {Nomes[i]} possui {CompNomes[i]} caracteres");
            }

        }
    }
}
