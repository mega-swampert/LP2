﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Exerc5 : Form
    {
        public Exerc5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[] totalAlunos = new int[9];
            int[] totalQuestoes = new int[10];
            string[] gabarito = {"A", "B", "C", "E", "D", "C", "A", "B", "D", "C"};


            for (int i = 0; i < totalAlunos.Length; i++)
            {
                for (int j = 0; j < totalQuestoes.Length; j++)
                {
                    string auxiliar = Interaction.InputBox($"Digite a resposta da pergunta {j + 1} do Aluno {i + 1}", "Entrada de Dados");

                    if (string.IsNullOrEmpty(auxiliar) || (string.IsNullOrWhiteSpace(auxiliar) || auxiliar != "A" && auxiliar != "B" && auxiliar != "D" && auxiliar != "E" && auxiliar != "C"))
                    {
                        MessageBox.Show("Resposta Inválida!");
                        j--;
                    }
                    else
                    if (!auxiliar.Contains(gabarito[j]))
                    {
                        lstbxTexto.Items.Add($"O aluno {i + 1} errou a questão {j + 1}: era {gabarito[j]} escolheu {auxiliar}");
                    }
                    else
                    if (auxiliar.Contains(gabarito[j]))
                    {
                        lstbxTexto.Items.Add($"O aluno {i + 1} acertou a questão {j + 1}: era {gabarito[j]} escolheu {auxiliar}");
                    }
                }
            }
        }
    }
}
