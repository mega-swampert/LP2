﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxNotas.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] alunos = new double[5];
            double[] notas = new double[3];
            double mediaGeral = 0;

            for (int j = 0; j < alunos.GetLength(0); j++)
            {
                for (int i = 0; i < notas.GetLength(0); i++)
                {
                    string auxiliar = Interaction.InputBox($"Digite a nota do professor {i + 1} para o aluno {j + 1}", "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out notas[i]) || notas[i] > 10 || notas[i] < 0)
                    {
                        MessageBox.Show("Número Inválido!");
                        i--;
                    }

                }
                alunos[j] = (notas[0] + notas[1] + notas[2]) / 3;
                mediaGeral = alunos[j] + mediaGeral;
                lstbxNotas.Items.Add($"Aluno {j + 1} Nota Professor 1: {notas[0].ToString("N2")} Nota Professor 2: {notas[1].ToString("N2")} Nota Professor 3: {notas[2].ToString("N2")} Média {alunos[j].ToString("N2")}");
            }
            lstbxNotas.Items.Add("------------------");
            lstbxNotas.Items.Add($"Média Geral dos Alunos: {(mediaGeral / 5).ToString("N2")}");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
