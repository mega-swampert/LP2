﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            lblResultado = new Label();
            txtResultado = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            btnSoma = new Button();
            btnSub = new Button();
            btnMult = new Button();
            btnDiv = new Button();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNumero1.Location = new Point(36, 91);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(96, 25);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Numero 1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNumero2.Location = new Point(36, 146);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(96, 25);
            lblNumero2.TabIndex = 1;
            lblNumero2.Text = "Numero 2";
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(194, 91);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(227, 23);
            txtNumero1.TabIndex = 0;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(194, 148);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(227, 23);
            txtNumero2.TabIndex = 1;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblResultado.Location = new Point(36, 207);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(94, 25);
            lblResultado.TabIndex = 4;
            lblResultado.Text = "Resultado";
            // 
            // txtResultado
            // 
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(194, 212);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(227, 23);
            txtResultado.TabIndex = 2;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLimpar.Location = new Point(575, 79);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(151, 71);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSair.Location = new Point(575, 168);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(152, 67);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnSoma
            // 
            btnSoma.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSoma.Location = new Point(36, 307);
            btnSoma.Name = "btnSoma";
            btnSoma.RightToLeft = RightToLeft.No;
            btnSoma.Size = new Size(132, 64);
            btnSoma.TabIndex = 8;
            btnSoma.Text = "+";
            btnSoma.UseVisualStyleBackColor = true;
            btnSoma.Click += btnSoma_Click;
            // 
            // btnSub
            // 
            btnSub.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSub.Location = new Point(209, 307);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(132, 64);
            btnSub.TabIndex = 9;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += btnSub_Click;
            // 
            // btnMult
            // 
            btnMult.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnMult.Location = new Point(387, 307);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(132, 64);
            btnMult.TabIndex = 10;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += btnMult_Click;
            // 
            // btnDiv
            // 
            btnDiv.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDiv.Location = new Point(553, 307);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(132, 64);
            btnDiv.TabIndex = 11;
            btnDiv.Text = "%";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += btnDiv_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDiv);
            Controls.Add(btnMult);
            Controls.Add(btnSub);
            Controls.Add(btnSoma);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtResultado);
            Controls.Add(lblResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblNumero2;
        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private Label lblResultado;
        private TextBox txtResultado;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnSoma;
        private Button btnSub;
        private Button btnMult;
        private Button btnDiv;
    }
}
