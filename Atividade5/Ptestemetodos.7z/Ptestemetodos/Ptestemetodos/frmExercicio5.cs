﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        int num1, num2;

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNumero1.Text, out num1) || (!int.TryParse(txtNumero2.Text, out num2)) || (num2 <= num1))
            {
                MessageBox.Show("Números Inválidos!");
                txtNumero1.Focus();
            }
            else
            {
                Random obj5 = new Random();
                int x = obj5.Next(num1, num2);
                MessageBox.Show("N° Sorteado: " + x);

            }
           

        }
    }
}
