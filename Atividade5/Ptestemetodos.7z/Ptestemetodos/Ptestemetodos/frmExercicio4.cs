﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contnum = 0;
            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                    contnum++;

                contador++;
            }
            if (contnum == 1)
                MessageBox.Show($"Tem {contnum} número");
            else
                MessageBox.Show($"Tem {contnum} números");
        }

        private void btnEspaço_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for (contador = 0; contador < rchtxtFrase.Text.Length; contador++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text, contador))
                    break;
            }
            if (contador == rchtxtFrase.TextLength)
                MessageBox.Show("Essa frase não possui espaços");
            else
                MessageBox.Show($"O primeiro espaço em branco está na posição {contador}");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int contletra = 0;

            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                    contletra++;
            }
            if (contletra == 1)
                MessageBox.Show($"Tem {contletra} letra");
            else
                MessageBox.Show($"Tem {contletra} letras");
        }
    }
}
